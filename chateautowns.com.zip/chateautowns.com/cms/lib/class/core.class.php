<?php   

	class CCore {
		
		var $vDatabase;

		/** comment here */
		function __construct() {
			$this->mDatabase = $GLOBALS["vDatabase"];
		}
	}

?>